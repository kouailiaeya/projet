<?php

namespace App\Controller;

use App\Repository\LivreRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Livre;
use Doctrine\ORM\EntityManagerInterface;

class LivreController extends AbstractController
{
   
     /**
     * Lists all books entities.
     *
     * @Route("/livre", name="livre.list")
     *@param LivreRepository $l
     * @return Response
     */
    public function list(LivreRepository $l) : Response
    {
        $Livres = $l->findActivebooks();//changer par findall() pour afficher meme les livre reserver

        return $this->render('livre/list.html.twig', [
            'livres' => $Livres,
        ]);
    }
     
     /**
     * Finds and displays a book entity.
     *
     * @Route("/livre/{id}", name="livre.show")
     *
     * @param Livre $livre
     *
     * @return Response
     */
    public function show(Livre $livre) : Response
    {
        return $this->render('livre/show.html.twig', [
            'livre' => $livre,
        ]);
    }
}
