<?php

namespace App\DataFixtures;

use App\Entity\Categorie;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;

class CategorieFixtures extends Fixture
{
    public function load(ObjectManager $manager)
    {
        // $product = new Product();
        // $manager->persist($product);


        $designCategory1 = new Categorie();
        $designCategory1->setLibelle('Romance');

        $designCategory2 = new Categorie();
        $designCategory2->setLibelle('Aventure');

        $designCategory3 = new Categorie();
        $designCategory3->setLibelle('Biographie');

        $designCategory4 = new Categorie();
        $designCategory4->setLibelle('sience fiction');

        $designCategory5 = new Categorie();
        $designCategory5->setLibelle('histoire');

        $manager->persist($designCategory1);
        $manager->persist($designCategory2);
        $manager->persist($designCategory3);
        $manager->persist($designCategory4);
        $manager->persist($designCategory5);

        $manager->flush();

        $this->addReference('category-Romance', $designCategory1);
        $this->addReference('category-Aventure', $designCategory2);
        $this->addReference('category-Biographie', $designCategory3);
        $this->addReference('category-siencefiction', $designCategory4);
        $this->addReference('category-histoire', $designCategory5);


        
    }
}
